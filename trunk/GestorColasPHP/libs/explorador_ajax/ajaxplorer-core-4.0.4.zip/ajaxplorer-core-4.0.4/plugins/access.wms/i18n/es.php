<?php

$mess=array(
"1" => "Nombre",
"2" => "Título",
"3" => "Consultable",
"4" => "Estilo",
"5" => "Palábras Clave",
"6" => "Proyección",
)

?>
