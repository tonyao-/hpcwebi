<?php
$mess = array(
    // will be replaced by the application title
    "1" => "%s öffentlicher Download",
    // will be replaced by the filename to download
    "2" => "Klicken Sie auf das Bild, um <b>%s</b> auf Ihre Festplatte zu speichern",
    "3" => "falsches Passwort",
    "4" => "Geben Sie das erforderliche Passwort ein und klicken Sie auf das Bild um <b>%s</b> auf Ihre Festplatte zu speichern",
    "5" => "Passwort",
    "6" => "Freigabe beenden",
    "7" => "Freigabe beenden löscht die Datei nicht. Wenn Sie die Parameter ändern wollen, bitte geben Sie die Datei erneut frei.",
    "8" => "Datei ist freigegeben",
    "9" => "Verwenden Sie diese Schaltfläche, um diesen Ordner freizugeben",
    "10"=> "Ordner ist freigegeben",
    "11"=> "Ablaufdatum",
    "12"=> "Passwort",
    "13"=> "Ja",
    "14"=> "Nein",
    "15"=> "Datei wurde %s mal heruntergeladen",
    "16"=> "Zurücksetzen",
    "17"=> "Klicken um den Zähler zurückzusetzen",
    "18"=> "Ordner ist als neues Repository freigegeben",
    "19"=> "Freigegebene Repository Optionen wurden erfolgreich geändert",
    "20"=> "Ooops, die gesuchte Datei konnte nicht gefunden werden! Möglicherweise wurde die Datei bereits entfernt, oder ist nicht mehr freigegeben."
);
?>
